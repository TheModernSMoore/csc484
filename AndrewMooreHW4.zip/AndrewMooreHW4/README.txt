For all parts, navigate to the folder with the desired part in the terminal then follow these steps:

type "make" in the terminal to run the makefile

then type "./main" to run the program

close the program by closing the window

Part 1-2: The character and monster will take actions based on their respective Decision and Behavior trees

I do not have a submission for Part 3.