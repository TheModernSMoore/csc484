#pragma once
#include <SFML/Graphics.hpp>

float length(sf::Vector2f vec);

sf::Vector2f normalize(sf::Vector2f vec);